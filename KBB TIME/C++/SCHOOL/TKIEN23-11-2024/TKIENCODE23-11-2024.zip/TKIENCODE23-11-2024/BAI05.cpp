#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,f,p,t,x,B;
vector<int> a,b;
vector<pair<int,bool>> c;
int res;
int32_t main()
{
    cin>>n>>f>>p>>t>>B;
    a.resize(f+1);
    b.resize(p+1);
    for(int i=1; i<=f; i++)
        cin>>a[i];
    for(int i=1; i<=p; i++)
        cin>>b[i];
    b.push_back(1);
    b.push_back(n);
    sort(a.begin(),a.end());
    sort(b.begin(),b.end());
    a.resize(unique(a.begin(),a.end())-a.begin());
    b.resize(unique(b.begin(),b.end())-b.begin());
    int i=1,j=1;
    while(i<a.size()&&j<b.size())
    {
        if(a[i]==b[j])
        {
            c.push_back({b[j],1});
            i++,j++;
        }
        else if(a[i]<b[j])
        {
            c.push_back({a[i],0});
            i++;
        }
        else if(a[i]>b[j])
        {
            c.push_back({b[j],1});
            j++;
        }
    }
    while(i<a.size())
    {
        c.push_back({a[i],0});
        i++;
    }
    while(j<b.size())
    {
        c.push_back({b[j],1});
        j++;
    }
    for(int k=1; k<c.size(); k++)
    {
        if(c[k].second)
        {
            if(c[k-1].second)
                res=res+min(B,(c[k].first-c[k-1].first)*t);
            else
                res=res+(c[k].first-c[k-1].first)*t;
        }
        else
            res=res+(c[k].first-c[k-1].first)*t;
    }
    cout<<res;
}
/*
20 4 4 6907 9625
6 9 15 18
6 10 15 18
ans: 66128
*/
